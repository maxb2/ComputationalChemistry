#!/bin/bash

for i in `seq 90 1 130`
do 
	cat $1 > $1".$i.gjf"
	echo "A1 $i.0" >> $1".$i.gjf"
done
